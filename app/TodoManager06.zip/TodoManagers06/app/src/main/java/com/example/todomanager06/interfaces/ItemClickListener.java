package com.example.todomanager06.interfaces;

public interface ItemClickListener {
    void onItemClick(int position);

    void itemClick();
}
