package com.example.todomanager06.interfaces;

import com.example.todomanager06.model.TaskModel;

public interface OnLongClickListener {
    void onItemPress(TaskModel model);
}
