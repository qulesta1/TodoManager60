package com.example.todomanager06.adapter;

public interface Listener {
}
